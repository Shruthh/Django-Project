import sqlite3
from pathlib import Path

# Path to the SQLite database file
db_path = Path(__file__).resolve().parent / 'db.sqlite3'

# Ensure the database file exists (optional)
if not db_path.exists():
    print("SQLite database not found. Ensure migrations are applied.")
