from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth.hashers import make_password
from .models import User, Role
from .serializers import UserSerializer, RoleSerializer

# authentication/views.py
from django.shortcuts import render

def index(request):
    return render(request, 'index.html')  # Make sure 'index.html' exists in the correct templates folder


class RegisterView(APIView):
    def post(self, request):
        data = request.data
        user = User.objects.create(
            username=data['username'],
            email=data['email'],
            password=make_password(data['password'])
        )
        return Response({'message': 'User created successfully'}, status=201)

class LoginView(APIView):
    def post(self, request):
        from django.contrib.auth import authenticate
        data = request.data
        user = authenticate(username=data['username'], password=data['password'])
        if user:
            refresh = RefreshToken.for_user(user)
            return Response({
                'refresh': str(refresh),
                'access': str(refresh.access_token),
            })
        return Response({'error': 'Invalid credentials'}, status=401)
    
class ProtectedView(APIView):
    permission_classes = [IsAuthenticated]  # Requires the user to be authenticated

    def get(self, request):
        return Response({"message": "You have access to the protected endpoint!"})


class RoleView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        roles = Role.objects.all()
        serializer = RoleSerializer(roles, many=True)
        return Response(serializer.data)

    def post(self, request):
        data = request.data
        role = Role.objects.create(name=data['name'])
        serializer = RoleSerializer(role)
        return Response(serializer.data, status=201)
