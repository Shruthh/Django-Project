// Get form elements
const registerForm = document.getElementById('register-form');
const loginForm = document.getElementById('login-form');
const rolesSection = document.getElementById('roles-section');
const rolesOutput = document.getElementById('roles-output');

// Register form submission
registerForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    const username = document.getElementById('register-username').value;
    const email = document.getElementById('register-email').value;
    const password = document.getElementById('register-password').value;

    try {
        const response = await axios.post('/api/register/', {
            username,
            email,
            password
        });
        alert('User registered successfully!');
    } catch (error) {
        console.error(error);
        alert('Registration failed');
    }
});

// Login form submission
loginForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    const username = document.getElementById('login-username').value;
    const password = document.getElementById('login-password').value;

    try {
        const response = await axios.post('/api/login/', {
            username,
            password
        });
        const { access, refresh } = response.data;
        localStorage.setItem('access_token', access);
        localStorage.setItem('refresh_token', refresh);

        alert('Login successful!');
        loginForm.reset();
        rolesSection.style.display = 'block';  // Show roles section
    } catch (error) {
        console.error(error);
        alert('Login failed');
    }
});

// View roles with JWT token
document.getElementById('view-roles-btn').addEventListener('click', async () => {
    const accessToken = localStorage.getItem('access_token');

    try {
        const response = await axios.get('/api/roles/', {
            headers: {
                'Authorization': `Bearer ${accessToken}`
            }
        });
        rolesOutput.textContent = JSON.stringify(response.data, null, 2);  // Display roles
    } catch (error) {
        console.error(error);
        alert('Failed to fetch roles');
    }
});
